export interface LogEntry {
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'debug';
  message: string;
  source?: string;
  metadata?: Record<string, any>;
}

export interface LogStats {
  totalEntries: number;
  errorCount: number;
  warnCount: number;
  infoCount: number;
  debugCount: number;
}

export interface FilterOptions {
  level?: string;
  search?: string;
  startDate?: string;
  endDate?: string;
  source?: string;
}