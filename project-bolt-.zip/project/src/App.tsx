import React, { useState, useCallback } from 'react';
import { LogTable } from './components/LogTable';
import { FilterPanel } from './components/FilterPanel';
import { Statistics } from './components/Statistics';
import { LogEntry, FilterOptions, LogStats } from './types';
import { parseLogFile } from './utils/logParser';
import { Upload } from 'lucide-react';

function App() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [filters, setFilters] = useState<FilterOptions>({});
  const [stats, setStats] = useState<LogStats>({
    totalEntries: 0,
    errorCount: 0,
    warnCount: 0,
    infoCount: 0,
    debugCount: 0
  });

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const parsedLogs = parseLogFile(content);
      setLogs(parsedLogs);
      
      // Calculate statistics
      const newStats = {
        totalEntries: parsedLogs.length,
        errorCount: parsedLogs.filter(log => log.level === 'error').length,
        warnCount: parsedLogs.filter(log => log.level === 'warn').length,
        infoCount: parsedLogs.filter(log => log.level === 'info').length,
        debugCount: parsedLogs.filter(log => log.level === 'debug').length
      };
      setStats(newStats);
    };
    reader.readAsText(file);
  }, []);

  const filteredLogs = logs.filter(log => {
    if (filters.level && log.level !== filters.level) return false;
    if (filters.search && !log.message.toLowerCase().includes(filters.search.toLowerCase())) return false;
    if (filters.startDate && new Date(log.timestamp) < new Date(filters.startDate)) return false;
    if (filters.endDate && new Date(log.timestamp) > new Date(filters.endDate)) return false;
    if (filters.source && log.source !== filters.source) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Log Analyzer</h1>
          
          <label className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer">
            <Upload className="w-5 h-5 mr-2" />
            Upload Logs
            <input
              type="file"
              onChange={handleFileUpload}
              className="hidden"
              accept=".log,.txt,.json"
            />
          </label>
        </div>

        <Statistics stats={stats} />
        <FilterPanel filters={filters} onFilterChange={setFilters} />
        
        <div className="bg-white rounded-lg shadow">
          <LogTable logs={filteredLogs} />
        </div>
      </div>
    </div>
  );
}

export default App;